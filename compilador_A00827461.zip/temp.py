myNum = [10, 20, 30, 40]
print(myNum)
myNum[0] = 15
myNum[(0 + 4)] = 10
print(myNum)