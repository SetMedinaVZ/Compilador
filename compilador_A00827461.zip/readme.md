# Bienvenidos
TC3002B ITESM

Proyecto de un pseudo compilador en Python para el modulo de compiladores de la clase Desarrollo de aplicaciones avanzadas de ciencias computacionales con el profesor Paco Peña.
Sientanse libres de usar el codigo para los que estan en esta clase con el mismo profesor, y  recuerden:

>Si Paco Peña opina, no estoy de acuerdo.

>Si Paco Peña habla, ignoro.

>Si Paco Peña falla, juzgo.

>Si Paco Peña piensa, desprecio.

>Si Paco Peña tiene 100 haters, yo soy uno de ellos.

>Si Paco Peña tiene 1 hater, yo soy ese hater.

>Si Paco Peña no tiene un hater, yo no existo.


## Como usar
Se puede usar el compilador de dos maneras:
1. **Archivo de texto**: Crear un archivo de texto con el código fuente y ejecutar el compilador con el nombre del archivo como argumento.
```bash
python compiler.py source_code.txt
```
2. **Pruebas automaticas**: Ejecutar el script de pruebas para correr las pruebas unitarias ya establecidas en la carpeta `codes`:
```bash
./compiler
```
